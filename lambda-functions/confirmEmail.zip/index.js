const AWS = require('aws-sdk');
const sns = new AWS.SNS();

exports.handler = async (event) => {
    try {

        console.log("Event: ", event);

        const { topicArn, email } = event;

        const subscribeParams = {
            Protocol: 'email',
            TopicArn: topicArn,
            Endpoint: email
        };

        await sns.subscribe(subscribeParams).promise();

        console.log("Confirmation email sent successfully.")

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Confirmation email sent successfully." })
        };
    } catch (error) {
        console.log("Error: ", error);

        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error occurred while sending confirmation email." })
        }

    }
};

